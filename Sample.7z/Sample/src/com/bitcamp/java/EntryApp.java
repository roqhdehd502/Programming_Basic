package com.bitcamp.java;

/**
 * 
 * 실행 시 반드시 main 함수를 작성하세요
 * 화면 출력 : System.out.println()
 * 가능한 출력은 한 번에 끝낸다....
 * 
 * @author 비트캠프
 *
 */
public class EntryApp {
	
	public static void main(String[] args) {
		// 화면에 텍스트를 출력하세요
		// - 가능한 함수호출은 한번에 끝낸다...
		String s =	100 + "원 \n";
		s += "korea";
		s += 300;
		System.out.println(s);
		
	}

}
