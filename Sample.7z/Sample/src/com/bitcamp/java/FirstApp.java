package com.bitcamp.java;

public class FirstApp {

	public static void main(String[] args) {
		
	}
	// 실행할 내용, 함수들 정의
	void func(int value)
	{
		int sum = value + 10;
	}
} // end

