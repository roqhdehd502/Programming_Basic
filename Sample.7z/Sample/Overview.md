
# 자바

1. 기본 규칙.
- package 정의하기. domain을 거꾸로 일반
- java source file ~.java
- coding ( save and compile )

2. 이름 짓기
- 첫 글자는 반드시 영문 대문자
- 기호 불가, 숫자는 가급적 불가
- 파일명과 클래스명이 같아야 한다. ( public )

3. 코딩 순서
- 패키지명을 작성
- 클래스를 정의한다.
- - 소스마다 클래스는 1개를 정의한다...
- - 함수들을 만든다....

4. 기술, 기능적 라이브러리 사용법
- import 

## 진입점 ( Entry Point )
- 최초 실행되는 함수
main()











